/**
  *Groupe : F
  *Equipe : GENCTURCK & GUELINA
  */
  
import java.util.*;

public class EtablissementBase extends Etablissement
{
	public EtablissementBase(String couleur, String nomCarte, String symbole, 
		                     String effet, int cout, int gain,int gain1, int[] resultatJet)
	{
		super (couleur, nomCarte, symbole, effet, cout, gain, gain1, resultatJet );
	}

}
