Compilation : javac @compile.list
Execution   : java Controleur
Jeu         : Selectionner un fichier TEST.txt parmi ceux disponibles
