 /**
 *
 * @author Chleo Binard , Armand Guelina , Thomas Leray & Ladislas Morcamp
 *
 */
 

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client extends Thread
{

    private InetAddress    ipAddress;
    private DatagramSocket socket   ;
   
    private int port;
    private int numJoueur;

    public Client(String ipAddress , int port  )
    {
        this.port      = port;
        this.numJoueur = 0;
        try
        {
            this.socket    = new DatagramSocket()            ;
            this.ipAddress = InetAddress.getByName(ipAddress);
        }
        catch(SocketException se){se.printStackTrace();       }
        catch(UnknownHostException uhe){uhe.printStackTrace();}
    }
    
    public void run()
    {
    	System.out.println("Veillez vous identifier ");
		sendData( write() );
		
		String message = receiveData().trim();
		String[] tmp = message.split( "\n" );
 		this.numJoueur = Integer.parseInt( tmp[1].substring( 20, 21 ) );
		System.out.println( message + "\n" );
		
		System.out.println( receiveData().trim() );
		System.out.println( receiveData().trim() + "\n");
		
		boolean finDePartie = false;
		
    	while ( !finDePartie )
    	{
 
    		message = receiveData().trim();
    		System.out.println( "\n" + message );
    		
    		if ( message.substring( 0, 2 ).equals( "10") )
    			sendData( write() );
    		
    		if ( message.substring( 0, 2 ).equals( "88" ) )
    			finDePartie = !finDePartie;
   
    	}
    }

    public String receiveData()
	{
		byte[] data           = new byte[2048];
		DatagramPacket packet = new DatagramPacket(data, data.length);
		try
		{
			socket.receive(packet);
		}
		catch(IOException ie){ie.printStackTrace();}
		
		return new String(packet.getData());
	}

    public void sendData( String message )
    {
    	byte[] data = message.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, ipAddress, port);
        try
        {
            socket.send(packet);
        }
        catch(IOException ie){ie.printStackTrace();}
    }
    
    
    public String write()
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		return str;
	}
    
    public static void main( String[] args )
	{
		new Client( "localhost", 8000 ).start();
	}
}
