

/**
 * Cette classe est le controleur. Elle fait le lien entre le métier (le tablier) et les ihm(IHMCUI & IHMGUI) selon le model MVC
 * @author Chleo Binard , Armand Guelina , Thomas Leray & Ladislas Morcamp
 *
 */
 
public class Controleur
{
	private IHM ihm;
	private Tablier    tablier;
	private Serveur    srv;
	
	private String mode;

	
	public Controleur( Serveur srv )
	{
		this.ihm     = null;
		this.tablier = new Tablier( this );
		this.srv     = srv;
		
		this.mode = "serveur";
	}
	
	
	/*------------------ Metier ------------------*/
	
	public String lancerPartie( Joueur[] ensJoueur )
	{
		return this.tablier.lancerPartie( ensJoueur );
	}
	
	public void jouerPartie()
	{
		this.tablier.jouerPartie();
	}
	
	public Tablier getTablier()
	{
		return this.tablier;
	}
	
	public Joueur[] getTabJoueur()
	{
		return this.tablier.getTabJoueur();
	}
	
	public Conteneur[][] getTabConteneur()
	{
		return this.tablier.getTabConteneur();
	}
	
	public boolean placerTwistLock( String text )
	{
		return this.tablier.placerTwistLock(text);	
	}

	public int getNbLigne()
    {
        return this.tablier.getNbLigne();
    }

    public int getNbColonne()
    {
        return this.tablier.getNbColonne();
    }
	
	public Joueur getJoueurCourant()
	{
		return this.tablier.getJoueurCourant();
	}
	
	
	
	/*------------------ IHM ------------------*/
	public void finDePartie( String strFin )
	{
		this.ihm.finDePartie( strFin );
	}

	public void maj()
	{
		this.ihm.maj();
	}
	
	public void afficherIHM()
	{
		this.ihm = new IHM( this );
	}
	
	public String getMode()
	{
		return this.mode;
	}
	
	
	/*------------------ Serveur ------------------*/
	public void tourDuJoueur( Joueur j )
	{
		this.srv.tourDuJoueur( j );
	}
	
	public void finDePartieSrv( Joueur j )
	{
		this.srv.finDePartie( j );
	}
	
}
