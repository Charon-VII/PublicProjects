

import java.awt.Color;

/**
 * Cette classe représente un joueur
 * 
 * @author Armand GUELINA, Chleo BINARD & Ladislas MORCAMP
 */
 
public class Joueur
{
	private static String[] strCouleur = { "ROUGE", "VERT", "BLEU", "JAUNE" };
	private static Color[]  tabCouleur = { Color.RED , Color.GREEN , Color.BLUE , Color.YELLOW };
	private static int nbJoueur = 1;
	
	private int numJoueur;
	private int score;
	private int nbTwistRestant;
	
	private String couleurJoueur;
	private String nom;
	private Color couleur;

	public Joueur( String nom , int nbTwist )
	{
		this.numJoueur     = Joueur.nbJoueur++ ;
		this.couleur       = Joueur.tabCouleur[this.numJoueur - 1];
		this.couleurJoueur = Joueur.strCouleur[this.numJoueur - 1];
		
		this.nom = nom;

		this.nbTwistRestant = nbTwist;
		this.score = 0;
	}
	
	public Joueur( String nom )
	{
		this( nom, 5 );
	}
	
	public Joueur( Joueur j )
	{
		this.numJoueur      = j.numJoueur;
		this.couleur        = j.couleur;
		this.couleurJoueur  = j.couleurJoueur;
		this.nom            = j.nom;
		this.nbTwistRestant = j.nbTwistRestant;
		this.score          = j.score;
	}

	public void decrementerNbTwistLowk( int nbTwist )
	{
		this.nbTwistRestant -= nbTwist;
	}

	public void ajouterPoint( int nbPoint )
	{
		this.score += nbPoint;
	}

	public int getNumJoueur()
	{
		return numJoueur;
	}

	public String getNom()
	{
		return nom;
	}

	public int getScore()
	{
		return score;
	}
	
	public void setScore(int score)
	{
		this.score = score;
	}

	public int getNbTwistRestant()
	{
		return nbTwistRestant;
	}

	public Color getCouleur()
	{
		return couleur;
	}
	
	public String getStrCouleur()
	{
		return this.couleurJoueur;
	}
	
	public boolean equals( Joueur j )
	{
		return j.couleurJoueur.equals( this.couleurJoueur );
	}

}
