/**
 * Cette classe représente un conteneur avec une valeur et un ensemble de coin
 * @author Chleo Binard , Armand Guelina , Thomas Leray & Ladislas Morcamp
 * 
 */

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;


public class Serveur extends Thread
{
	private static String[] strCouleur = { "ROUGE", "VERT", "BLEU", "JAUNE" };
	
	private HashMap<Joueur, DatagramPacket> hm;
	private DatagramSocket socket;
	private Controleur ctrl;
	
	private int nbJoueur; 
	
	
	public Serveur()
	{
		this.ctrl = new Controleur( this );
		this.nbJoueur = 0;
		try
		{
			this.socket = new DatagramSocket(8000);
			this.hm     = new HashMap<Joueur, DatagramPacket>();
		}
		catch( SocketException se ){ se.printStackTrace(); }
	}
	
	//Utilisation d'un Tread pour mieux gerer les evenements 
	public void run()
	{
		System.out.println("\n\n\t DEMARRAGE DU SERVEUR DE L'EQUIPE 17\n\n\t En attente d'au moins 2 clients.......\n\n");
		while(true)
		{
			byte[]         data   = new byte[1024];
			DatagramPacket packet = new DatagramPacket(data, data.length);
			try
			{
				socket.receive(packet);
			}
			catch(IOException ie){ie.printStackTrace();}
			
			String message = new String(packet.getData()) ;
			verificationConnexion(message, packet);
			
			if  (this.nbJoueur >=2 ) { lancerPartie(); }
		}
	}
	
	
	public synchronized void verificationConnexion(String message, DatagramPacket packet)
	{
		String str = "";
		
		//Verifie l'identifiant envoye par les clients et si elle est valide, donne une couleur a chaque client
		if ( this.nbJoueur < 2 )
		{
			String nomJoueur = message.trim();
			this.nbJoueur ++;
			str += this.nbJoueur + "-Bonjour " + nomJoueur + "\n";
			
			str += "Vous etes le Joueur " + this.nbJoueur + " (" + Serveur.strCouleur[ this.nbJoueur-1 ] + "), attente suite ...";
			sendData(str.getBytes(), packet.getAddress(), packet.getPort());
			
			hm.put( new Joueur( nomJoueur ), packet);
			System.out.println("Client "+ this.nbJoueur + " (ip : " +packet.getAddress()+" port : " + packet.getPort() + " )" + " connecté au serveur");

		}
		//Si identifiant invalide
		else
		{
			str += "91-demande non valide";  
			sendData(str.getBytes(), packet.getAddress(), packet.getPort());
		}	
	}
	
	// Méthode permetant d'envoyer des données aux les clients
	public void sendData( byte[] data, InetAddress ipAddress, int port )
	{
		DatagramPacket packet = new DatagramPacket( data, data.length, ipAddress, port );
		try
		{
			socket.send(packet);
		}
		catch(IOException ie){ie.printStackTrace();}
	}
	
	public String receivedData( DatagramPacket packet )
	{
		try
		{
			socket.receive( packet );
		}
		catch(IOException ie){ie.printStackTrace();}
		 
		return new String( packet.getData() ).trim();
	}
	
	//Gere le preparatifs liees au debut du jeu ainsi que l'affichage de la map
	public void lancerPartie()
	{
		Joueur[] ensJoueur = new Joueur[hm.size()]; //Tableau reserve aux noms des joueurs
		
		String str = "01-la partie va commencer";
		String map = "MAP=";
		int i      = 0 ;
		
		for ( Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet() )
		{
			ensJoueur[i] = entry.getKey();
			i++;
		}
		
		map += this.ctrl.lancerPartie( ensJoueur );
		System.out.println( map );
		
		//Envoi d'un message a tous les joueurs pour prevenir le debut du jeu + envoie de la map
		for ( Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet() )
		{
			sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
			sendData(map.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
		}
		
		this.ctrl.jouerPartie();
	}
	
	
	public void tourDuJoueur( Joueur j )
	{
		String str = "";
		DatagramPacket packet = null;
		
		for (Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet())
		{
			if( entry.getKey().equals( j ) )
			{
				packet = entry.getValue();
				str = "10-A vous de jouer (" + j.getStrCouleur() + ") :" ;
				sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
			}
		}
		

		if ( packet != null )
		{
			try
			{
				socket.receive( packet );
			}
			catch ( IOException ie )  { ie.printStackTrace(); }
			
			String message = new String( packet.getData() ).trim();
			message = message.substring( 0, packet.getLength() );
			
			boolean coupValide = this.ctrl.placerTwistLock( message );
			
			for (Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet())
			{
				if( !entry.getKey().equals( j ) && coupValide )
				{
					packet = entry.getValue();
					str = "20-coup adversaire:"+ message;
					sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
				}
				else if( !entry.getKey().equals( j ) && !coupValide )
				{
					packet = entry.getValue();
					str = "22-coup adversaire illegal" ;
					sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
				}
				
				else if( entry.getKey().equals( j ) && !coupValide )
				{
					packet = entry.getValue();
					str = "21-coup joue illegal";
					sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
				}
			}
			
			if ( j.getNbTwistRestant() <= 0 )
			{
				str = "50-Vous ne pouvez plus jouer";
				sendData(str.getBytes(), packet.getAddress(), packet.getPort());
			}	
		}
	}
	
	public boolean joueurConnecte( DatagramPacket packet )
	{
		try
		{
			String str = "";
			sendData( str.getBytes(), packet.getAddress(), packet.getPort() );
			return true;
		} catch( Exception ie) { ie.printStackTrace(); return false; }
	}
	
	public void finDePartie( Joueur j )
	{
		String str = "";
		int scorePerdant = 0;
		for (Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet())
			if ( !entry.getKey().equals( j ) )
				scorePerdant = entry.getKey().getScore();
		
		for (Map.Entry<Joueur, DatagramPacket> entry : hm.entrySet())
		{
			if ( j == null )
				str = "88-Partie termine, egalite " + j.getScore() + " - " + j.getScore();
			if ( entry.getKey().equals( j ) )
				str = "88-Partie termine, vous avez gagné " + j.getScore() + " - " + scorePerdant;
			else
				str = "88-Partie termine, vous avez perdu " + scorePerdant + " - " + j.getScore();
			
			sendData(str.getBytes(), entry.getValue().getAddress(), entry.getValue().getPort());
		}
	}
	
	public static void main( String[] args )
	{
		new Serveur().start();
	}
}
