
import java.io.*;
import java.util.*;



/**
 * Cette classe représente un tablier un ensemble de conteneur et un ensemble de joueur dont elle gere les mouvements
 * @author Armand GUELINA, Chleo Binard & Ladislas Morcamp
 * 
 */
 
public class Tablier
{
	Controleur ctrl;
	Conteneur[][] tabConteneur;
	Joueur[] tabJoueur;

	
	private Joueur joueurCourant;
	private int cptJoueur;

	public Tablier( Controleur ctrl )
	{
		this.ctrl  = ctrl ;
		this.cptJoueur = 0;
	}
	
	
	public String lancerPartie( Joueur[] ensJoueur )
	{
		int nbLig = (int)( Math.random()*(9-4)+4 );
		int nbCol = (int)( Math.random()*(9-4)+4 );
		
		this.tabConteneur = new Conteneur[nbLig][nbCol];
		
		for( int cptLig = 0 ; cptLig < tabConteneur.length ; cptLig++ )
			for( int cptCol = 0 ; cptCol < tabConteneur[cptLig].length ; cptCol++ )
				this.tabConteneur[cptLig][cptCol] = new Conteneur( this );
		
		this.tabJoueur = ensJoueur;
		
		String map = "";
		for( int cptLig = 0 ; cptLig < tabConteneur.length ; cptLig++ ) {
			for( int cptCol = 0 ; cptCol < tabConteneur[cptLig].length ; cptCol++ )
			{
				map += "" + this.tabConteneur[cptLig][cptCol].getNumConteneur();
				if ( cptCol != tabConteneur[cptLig].length-1 )
					map += ":";
			}
			map += "|";
		}
		

		joueurCourant = this.tabJoueur[0];
		this.ctrl.afficherIHM();
		return map;
	}
	
	public void jouerPartie()
	{
	
		while ( !this.partisEstFini() )
		{
			
			if ( joueurCourant.getNbTwistRestant() > 0 )
				this.ctrl.tourDuJoueur( joueurCourant );

			 // on prends le joueur suivant Si il a 0 twist lock on répete
			if( !this.partisEstFini() )
			{
		        do
		        {
		            cptJoueur = (cptJoueur+1) == this.tabJoueur.length ? 0 : cptJoueur+1;
		            joueurCourant = this.tabJoueur[cptJoueur];
		        }while( joueurCourant.getNbTwistRestant() <= 0 );
			}
	    }
		
		
		System.out.println( "FIN" );

		if ( tabJoueur[1].getScore() ==  tabJoueur[0].getScore() )
		{
			this.ctrl.finDePartie( "Egalite entre " + tabJoueur[0].getNom() + " (" + tabJoueur[0].getStrCouleur() + ") " + " et " + tabJoueur[0].getNom() + " (" + tabJoueur[1].getStrCouleur() + ") "  + "avec : " + tabJoueur[0].getScore() + " points");
			this.ctrl.finDePartieSrv( null );
		}
		else if ( tabJoueur[1].getScore() >  tabJoueur[0].getScore() )
		{
			this.ctrl.finDePartie( tabJoueur[1].getNom() + " (" + tabJoueur[1].getStrCouleur() + ") " + "avec : " + tabJoueur[1].getScore() + " points");
			this.ctrl.finDePartieSrv( tabJoueur[1] );
		}
		else
		{
			this.ctrl.finDePartie( tabJoueur[0].getNom() + " (" + tabJoueur[0].getStrCouleur() + ") " + "avec : " + tabJoueur[0].getScore() + " points");
			this.ctrl.finDePartieSrv( tabJoueur[0] );
		}
		this.ctrl.maj();
	}

	
	public boolean placerTwistLock( String texte )
	{
				
		// Permet deffectuer les action et si il y a une erreur de saisie de la par du joueur c'est une erreur
		// donc le catch enleve 2 Twist lock
		try
		{
			int numLig = Integer.parseInt( texte.substring(0, texte.length()-2) ) -1;
            int numCol = (int)(texte.charAt( texte.length()-2)-'A');
            int numCoin = Integer.parseInt( texte.charAt(texte.length()-1)+"" )-1;

			if( !this.tabConteneur[numLig][numCol].coinEstLibre( numCoin ) )
				Integer.parseInt( "Go le catch" );
				
			if( numCoin == 0 )
			{
				// chaque set est dans un try catch parce que si on pose dans un coter on peut pas
				// set en dehors
				try{this.tabConteneur[numLig]  [numCol]  .setTwistLock( 0 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig]  [numCol  ].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig]  [numCol-1].setTwistLock( 1 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig]  [numCol-1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig-1][numCol-1].setTwistLock( 2 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig-1][numCol-1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig-1][numCol]  .setTwistLock( 3 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig-1][numCol  ].getNumConteneur());}catch(Exception e) {}
			}
			else if( numCoin == 1 )
			{
				try{this.tabConteneur[numLig]  [numCol]  .setTwistLock( 1 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol  ].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig]  [numCol+1].setTwistLock( 0 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol+1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig-1][numCol]  .setTwistLock( 2 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig-1][numCol  ].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig-1][numCol+1].setTwistLock( 3 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig-1][numCol+1].getNumConteneur());}catch(Exception e) {}
			}
			else if( numCoin == 2 )
			{
				try{this.tabConteneur[numLig]  [numCol]  .setTwistLock( 2 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol  ].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig]  [numCol+1].setTwistLock( 3 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol+1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig+1][numCol+1].setTwistLock( 0 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig+1][numCol+1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig+1][numCol]  .setTwistLock( 1 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig+1][numCol  ].getNumConteneur());}catch(Exception e) {}
			}
			else if( numCoin == 3 )
			{
				try{this.tabConteneur[numLig]  [numCol]  .setTwistLock( 3 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol  ].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig]  [numCol-1].setTwistLock( 2 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig  ][numCol-1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig+1][numCol-1].setTwistLock( 1 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig+1][numCol-1].getNumConteneur());}catch(Exception e) {}
				try{this.tabConteneur[numLig+1][numCol]  .setTwistLock( 0 , cptJoueur+1 );joueurCourant.ajouterPoint( this.tabConteneur[numLig+1][numCol  ].getNumConteneur());}catch(Exception e) {}
			}
			joueurCourant.decrementerNbTwistLowk( 1 );
			System.out.println( "Twist-Lock poser -1 Twist" );
			
			return true;
		}
		catch( Exception e )
		{
			System.out.println( "Erreur, une faute a été comise dans la saisie -2 Twist." );
			joueurCourant.decrementerNbTwistLowk( 2 );
			return false;
		}
	}

	public boolean partisEstFini()
	{
		for( int cpt = 0 ; cpt < tabJoueur.length ; cpt++ )
			if( tabJoueur[cpt].getNbTwistRestant() > 0 )
				return false;
		return true;
	}
	
	//Retourne le nom et le score du perdant
	public String perdant()
	{
		int    min =1000 ;
		String data="";
		for( int cpt = 0 ; cpt < tabJoueur.length ; cpt++ )
		{
			if( tabJoueur[cpt].getScore() < min )
			{
				min  = tabJoueur[cpt].getScore();
				data = tabJoueur[cpt].getNom()+ " Perd la partie avec " + tabJoueur[cpt].getScore() + " points ";
			}
		}		
		return data;
	}
	
	//Retourne le nom et le score du vainqueur
	public String vainqueur()
	{
		int    max =0 ;
		String data="";
		for( int cpt = 0 ; cpt < tabJoueur.length ; cpt++ )
		{
			if( tabJoueur[cpt].getScore() > max )
			{
				max  = tabJoueur[cpt].getScore();
				data = tabJoueur[cpt].getNom()+ " Remporte la partie avec " + tabJoueur[cpt].getScore() + " points ";
			}
		}		
		return data;
	}
	
	public Joueur[] getTabJoueur()
	{
		Joueur[] tmp = new Joueur[ this.tabJoueur.length ];
		for( int i = 0 ; i < tabJoueur.length ; i++ )
			tmp[i] = new Joueur( this.tabJoueur[i] );
		
		return tmp;
	}
	
	public int getNbLigne()
    {
        return this.tabConteneur.length;
    }

    public int getNbColonne()
    {
        return this.tabConteneur[0].length;
    }
	
    public Joueur getJoueurCourant()
	{
		return this.joueurCourant;
	}
	
    public int getNbJoueur()
    {
    	return this.tabJoueur.length;
    }
	
	public Conteneur[][] getTabConteneur()
	{
		Conteneur[][] tmp = new Conteneur[ this.tabConteneur.length ][ this.tabConteneur[0].length ];
		for( int cptLig = 0 ; cptLig < tabConteneur.length ; cptLig++ )
			for( int cptCol = 0 ; cptCol < tabConteneur[cptLig].length ; cptCol++ )
			{
				tmp[cptLig][cptCol] = new Conteneur( this.tabConteneur[cptLig][cptCol] );
			}
				
		
		return tmp;
	}
}
